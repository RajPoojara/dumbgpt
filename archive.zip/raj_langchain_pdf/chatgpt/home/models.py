from django.db import models
import datetime

# Define the Session model
class Session(models.Model):
    # Session key field
    skey = models.CharField(max_length=225)

    # Return session key as string representation
    def __str__(self):
        return self.skey
    
    @classmethod
    def get_session(cls, skey):
        try:
            return cls.objects.get(skey=skey)
        except cls.DoesNotExist:
            return None

# Define the SessionData model
class SessionData(models.Model):
    # Question and answer fields
    question = models.CharField(max_length=255, default='')
    answer = models.TextField(max_length=255, default='')

    # Foreign key to Session model
    sessions = models.ForeignKey(Session, on_delete=models.CASCADE)

    # Return session data as string representation
    def __str__(self):
        return f"{self.question}"
    
