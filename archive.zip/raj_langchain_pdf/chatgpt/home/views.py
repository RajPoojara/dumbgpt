from django.shortcuts import render,HttpResponse
import openai
COMPLETIONS_MODEL = "text-davinci-003"
import sys
import time
import time
import json
import os
from json import JSONEncoder
from .models import SessionData,Session
import langchain
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import Chroma
from langchain.text_splitter import CharacterTextSplitter
from langchain import OpenAI, VectorDBQA
from langchain.document_loaders import PyPDFLoader

prev_chat={}

os.environ['OPENAI_API_KEY'] = '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'
loader = PyPDFLoader('./static/git.pdf')
documents = loader.load()
text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
texts = text_splitter.split_documents(documents)
embeddings = OpenAIEmbeddings(openai_api_key=os.environ['OPENAI_API_KEY'])
docsearch = Chroma.from_documents(texts, embeddings)
qa = VectorDBQA.from_chain_type(llm=OpenAI(temperature=0), chain_type="map_rerank", vectorstore=docsearch)
    
# def main(self):
#     con = True
#     while con:
#         query = input("Ask your question:")
#         print(self.qa.run(query))
#         if input("Ask new Question? y or n:").lower() != "y":
#             con = False


def index(request,question=""):    
    questions_and_answers = []
         
    message=""
    if request.method == 'POST'and request.POST.get('new-chat'):
        if not request.session.session_key:
            request.session.save()
            # Get the session ID
        session_id = request.session.session_key
        if session_id:
            # delete the session object from the database
            Session.objects.filter(skey=session_id).delete()
         
    if request.method == 'POST'and request.POST.get('submit'):
        prev_question=request.POST.get('input_response')
        answer=request.POST.get('my_text')
        if not request.session.session_key:
            request.session.save()
        # Get the session ID
        session_id = request.session.session_key
        session = Session.get_session(skey=session_id)
        str_session=str(session)
        print(session_id)
        if session_id != str_session:
            session = Session.objects.create(skey=session_id)
        if prev_question != None and prev_question != '':
            answer=request.POST.get('my_text').strip(" ").strip()
            SessionData.objects.create(question=prev_question, answer=answer, sessions=session)
        
        # Get the session object for the current session key
        session_key = session_id
        session = Session.get_session(session_key)

        # If the session object exists, get all the SessionData objects for that session
        if session:
            session_data = SessionData.objects.filter(sessions=session)

            # Loop through the session_data objects and append the question and answer to the questions_and_answers list
            for data in session_data:
                questions_and_answers.append({'question': data.question, 'answer': data.answer})
        
        q_a=questions_and_answers
    if request.method == 'POST'and request.POST.get('submit'):   
        if question is None and question == " ":
            question = ""
            responce = ""
        question=request.POST.get('input_text').strip(" ").strip()
        print("I am Running")
        question3=list(question.split(" "))
        while("" in question3):
            question3.remove("")
        question=" ".join(question3)
            
    elif request.method == 'POST' and request.POST.get('submit-res'):
        question=request.POST.get('input_response').strip()
        question3=list(question.split(" "))
        print(question3)
        print("Second Running")
        while("" in question3):
            question3.remove("")
        question=" ".join(question3)
        question=question
        #prev_question.append(question)
        session_id = request.session.session_key
    
        # Get the session object for the current session key
        session_key = session_id
        session = Session.get_session(session_key)
        # If the session object exists, get all the SessionData objects for that session
        if session:
            session_data = SessionData.objects.filter(sessions=session)
            # Loop through the session_data objects and append the question and answer to the questions_and_answers list
            for data in session_data:
                questions_and_answers.append({'question': data.question, 'answer': data.answer})
    if question!="":
        message = qa.run(question).lstrip()
    #message = responce.choices[0].text.strip().replace(',','\n').replace('\n ','\n')
    print(message)
    question =  question
    # message= responce
        # print(message)
    return render(request, 'index.html',{'ans':message,'questions':question,'history': prev_chat,'history':questions_and_answers})

def about(request):
    return HttpResponse('This is About Page')
