from django import forms

class UserForm(forms.Form):
    input_test = forms.CharField(max_length=50000)