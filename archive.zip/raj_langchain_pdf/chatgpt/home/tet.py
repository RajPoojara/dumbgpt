str="""Industrial Pressure Sensor 0psi to 1000psi Sealed Gage 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0bar to 10bar Sealed Gage
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 667psi Sealed Gage
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 500psi Sealed Gage
            Industrial Pressure Sensor 0psi to 250psi Sealed Gage 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 250psi Sealed Gage 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 667psi Sealed Gage 3-Pin
            Industrial Pressure Sensor 0psi to 500psi Sealed Gage Medical 3-Pin
            Industrial Pressure Sensor 0bar to 40bar Sealed Gage 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 250psi Sealed Gage 3-Pin
            Industrial Pressure Sensor 0psi to 500psi Vented Gage 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0bar to 10bar Vented Gage Medical 3-Pin
            Industrial Pressure Sensor 0bar to 10bar Vented Gage Medical 3-Pin
            Industrial Pressure Sensor 0psi to 250psi Gage 4-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0bar to 70bar Gage Automotive 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 5000psi Gage Automotive 3-Pin
            Industrial Pressure Sensor 0psi to 500psi Gage Automotive 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 50psi Gage Automotive 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 150psi Gage Automotive
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 15psi Gage
            Industrial Pressure Sensor 1V to 5V 0bar to 0.14bar Gage Automotive 3-Pin
            Industrial Pressure Sensor 1V to 5V 0psi to 1000psi Gage Automotive 3-Pin
            Industrial Pressure Sensor 1V to 5V 0psi to 5psi Gage Automotive 3-Pin
            Industrial Pressure Sensor 0V to 10V 0psi to 15psi Gage 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 2psi Gage 4-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 750psi Absolute 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 150psi Absolute 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 250psi Absolute 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 5000psi Absolute 5-Pin
            Industrial Pressure Sensor 0bar to 2bar Absolute 3-Pin
            Industrial Pressure Sensor 0bar to 2bar Absolute Automotive 3-Pin
            Industrial Pressure Sensor 0.5V to 4.5V 0psi to 50psi Gage Automotive 3-Pin """
s=str.replace("    ","")
print(s)