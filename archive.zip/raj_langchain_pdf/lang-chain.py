import langchain


class LangChain:
    def __init__(self) -> None:
        from langchain.embeddings.openai import OpenAIEmbeddings
        from langchain.vectorstores import Chroma
        from langchain.text_splitter import CharacterTextSplitter
        from langchain import OpenAI, VectorDBQA
        from langchain.document_loaders import PyPDFLoader
        import os

        os.environ['OPENAI_API_KEY'] = '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'
        loader = PyPDFLoader('Employee_Handbook_v2.0.pdf')
        documents = loader.load()
        text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
        texts = text_splitter.split_documents(documents)
        embeddings = OpenAIEmbeddings(openai_api_key=os.environ['OPENAI_API_KEY'])
        docsearch = Chroma.from_documents(texts, embeddings)
        self.qa = VectorDBQA.from_chain_type(llm=OpenAI(), chain_type="stuff", vectorstore=docsearch)
        
    def main(self):
        con = True
        while con:
            query = input("Ask your question:")
            print(self.qa.run(query))
            if input("Ask new Question? y or n:").lower() != "y":
                con = False

langchain = LangChain()
langchain.main()