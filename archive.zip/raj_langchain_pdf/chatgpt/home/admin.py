from django.contrib import admin
from .models import SessionData,Session
# Register your models here.
admin.site.register(SessionData)
admin.site.register(Session)